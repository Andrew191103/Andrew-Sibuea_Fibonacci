#include "teslib/mylib.h"

int main(void){
    int x;
    while (1) {
        x = iterative(1000);
        }
    return 0;
}