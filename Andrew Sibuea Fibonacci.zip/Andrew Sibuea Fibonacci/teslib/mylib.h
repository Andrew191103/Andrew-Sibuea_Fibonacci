int iterative(int x);
int recursive(int x);